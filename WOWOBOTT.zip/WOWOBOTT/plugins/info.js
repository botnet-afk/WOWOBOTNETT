let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 WOWOBOTNET INFO 〙 ═
╠➥ Dibuat dengan bahasa javascript via NodeJs
╠➥ Rec: Drawl Nag
╠➥ Script: @Nurotomo
║
╠➥ Github: https://github.com/botnet-afk/
╠➥ Instagram: @setyo.wibowo27
╠➥ YouTube: CUKIMAY CYBER TEAM
║
╠═〘 Thanks To 〙 ═
╠➥ Noniod7
╠➥ Zefian
╠➥ Cubjrnet7
╠➥ and All member cukimay cyber team official:)
║
╠═〘 DONASI 〙 ═
╠➥ dana: 081231971005
╠➥ Pulsa: tsel: 081231971005
╠➥ Ovo: 081231971005
║
║>Request? Wa.me/6281231971005
║
╠═〘 WOWOBOTNET 〙 ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
